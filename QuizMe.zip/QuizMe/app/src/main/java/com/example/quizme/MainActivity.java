package com.example.quizme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<String> arrayList = new ArrayList<>();
    public static ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Array> Save = new ArrayList<>();

        Array ite1 = new Array("كم عدد عظمات جسم الانسان","206","306","250","350");

        arrayList.add(" كم عدد العظام بجسم الانسان " + " 206      ");
        arrayList.add(" كم عدد اسنان الانسان " + " 32      ");
        arrayList.add(" كم كليه لدى الانسان " + " 2      ");






        //دقمه ال+
        TextView Next = findViewById(R.id.next);
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(in);
            }
        });







       // arrayList = MainActivity.arrayList;
//        arrayList = MainActivity2.arrayList;

        final ListView list = findViewById(R.id.list);

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayList);
        list.setAdapter(arrayAdapter);
    }
}