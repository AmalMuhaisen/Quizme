package com.example.quizme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button save = findViewById(R.id.button1);
        final EditText et1 = findViewById(R.id.edit);
        final EditText et2 = findViewById(R.id.edit2);
        final EditText et3 = findViewById(R.id.edit3);
        final EditText et4 = findViewById(R.id.edit4);
        final EditText et5 = findViewById(R.id.edit5);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // MainActivity.arrayList.add(et1.getText().toString(),et2.getText().toString(),et3.getText().toString(),et4.getText().toString(),et5.getText().toString());
//                MainActivity.arrayList.add(et2.getText().toString());
//                MainActivity.arrayList.add(et3.getText().toString());
//                MainActivity.arrayList.add(et4.getText().toString());
//                MainActivity.arrayList.add(et5.getText().toString());
               // Toast.makeText(MainActivity2.this,et1.getText().toString(),Toast.LENGTH_LONG).show();




            }
        });
    }
}